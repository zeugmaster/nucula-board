# Project libraries and attribution

KiCad project tables register `Nucula_Project` with relative `${KIPRJMOD}` paths.
No workstation-global custom library is required.

- ESP32-C3-MINI-1-H4X symbol: adapted from the project WROOM drawing with
  Espressif datasheet v2.2 pin numbers, all 22 GND pins and explicit NC pins.
  The `_NoEPADSolder` footprint and STEP derive from [Espressif's official
  KiCad library](https://github.com/espressif/kicad-libraries), under
  [CC-BY-SA 4.0 with the design exception](../LICENSES/Espressif-KiCad-libraries.md).
  Perimeter lands and antenna keepout are retained; optional EPAD 49 is one
  5.4 mm masked GND land without paste or thermal holes. Front legend outside
  the PCB is omitted. The module is locked with its antenna tip flush at x=110 mm.
  [Pin, land and cutout checks](../docs/esp32-mini.md).
- Historical ESP32-C3-WROOM-02-N4 symbol, footprint and STEP: KiCad Library Team's
  ESP32-C3-WROOM-02 assets from installed KiCad 10.0.6, specialized with N4/4 MB
  metadata. Footprint pad geometry and antenna keepout are preserved.
- ESP32-C3-WROOM-02-N4_NoEPADSolder: project variant for the standard-fabrication
  revision. The optional centre joint has one masked GND land, no paste windows
  and no thermal-hole array. Edge pads, required GND pin 9 and antenna keepout
  are retained. [Rationale and checks](../docs/standard-fabrication.md).
- USB_C_GCT_USB4105_16P_Standard: project variant using 0.70 mm plated shell
  slots and at least 0.30 mm rings. Outer GND lands are 0.60 × 1.05 mm at
  local Y = −3.73 mm to achieve 0.25 mm NPTH clearance. Slot/peg centres remain
  unchanged. Adapted from the KiCad pattern and GCT drawing; physical fit is
  untested. [Dimensions](../docs/standard-fabrication.md).
- TLV803EA30DBZR: adapted from KiCad's TPS3839DBZ drawing. Corrected to the
  TLV803E open-drain output, SOT-23 footprint, ordering code and documentation.
- USB_C_GCT_USB4105_16P_JLCPCB: adapted from KiCad 10.0.6's GCT USB4105
  footprint. The two outer ground lands (A1/B12 and A12/B1) are shortened
  0.04 mm only at the locating-hole end: 0.60 × 1.11 mm at Y = −3.70 mm.
  Holes, shell stakes, other pads, outlines and the standard STEP model are
  unchanged. [Dimensions and manufacturing audit](../docs/usb-connector-clearance.md).
- JST_SH_SM02B-SRSS-TB_1x02-1MP_P1.00mm_Horizontal: installed KiCad library
  footprint copied unchanged for J2 / SM02B-SRSS-TB(LF)(SN), JLCPCB C160402.
  Side entry, 1.00 mm pitch, 2.95 mm mated height. Two electrical lands and two
  unconnected hold-downs, all with paste. Standard SH STEP model retained.
  Checked against the [JST drawing](../parts%20documentation/JST-SH-side-entry-2026-10-07.pdf),
  pages 1 and 3. The earlier vertical B2B-PH and horizontal S2B-PH footprints
  remain unassigned historical assets. [Selection](../docs/battery-connector.md).
- MouseBite_2Rows7_D0.60_P1.00_Inset_Gap2.00: project mechanical footprint
  for MB1/MB2, with two rows of seven 0.60 mm NPTH holes on 1.00 mm centers.
  The adjoining slots are defined by the PCB's Edge.Cuts geometry. This is a
  board-only drilling feature, excluded from BOM/POS output, with no 3D model.
  See the [keyboard breakaway guide](../docs/keyboard-breakaway.md).
- TP4054-42-SOT25R and SY8089AAAC: adapted from the embedded Olimex Rev C
  symbols. Corrected part names, pin electrical types, datasheets and footprint
  filters; replaced internal artwork with clean outlines and removed the old
  component-specific annotations.
- L_Taiyo-Yuden_NR-30xx: KiCad land pattern copied unchanged. Removed its
  missing 3D-model reference. No substitute model is claimed.
- PN7160A1HN_C100E: project-local copy of the installed part, with a new readable
  symbol drawing using NXP's HVQFN40 pin map, including exposed ground pad 41.
  The KiCad-derived land pattern is included. The optional SamacSys STEP model
  and its references are omitted from the public repository and release archives:
  its [terms](../LICENSES/PN7160-model-SamacSys.txt) prohibit distributing reusable
  library models outside the company. The electrical footprint is unchanged.
- SSD1309_COG_24: 24-contact glass interface checked against the user's exact
  CON24 breakout schematic. These are flex/contact numbers, not bare SSD1309
  die pads. The new reference supersedes the earlier 26-contact assumption.
  The assigned **Hirose FH12A-24S-0.5SH(55)** socket has 0.5 mm pitch, top
  contacts and a 0.30 mm flex requirement. Its project-local footprint uses
  Hirose drawing EDC3-150555-51 sheet 1: 0.30 × 1.30 mm signal lands,
  0.25 × 1.30 mm separate paste apertures and 1.80 × 2.20 mm mounting lands.
  The independently authored VRML envelope is a simplified closed-latch
  illustration generated from published dimensions; it is not vendor CAD.
  Regenerate both with `tools/generate_fh12a_footprint.py`. The downloaded
  manufacturer STEP model is not distributed with the project.
  The user confirms NFP1309-02Y pitch/thickness and mounted contacts facing
  away from the PCB. [Connector checks](../docs/oled24/top-contact.md).
  DS1 purchases only the socket; the display and keyboard modules remain
  excluded from the assembly BOM. No display-glass assembly model is claimed.
- Crystal_NDK_NX2016SA_2.0x1.6mm: adapted from KiCad's four-pad 2016 crystal
  footprint and standard package model, with NDK EXD14B-00467 recommended
  0.85 × 0.75 mm lands at 1.35 × 1.05 mm center spacing. Y1 uses the exact
  NX2016SA-27.12MHZ-EXS00A-CS06346 reference in NXP AN14518.
- NFC_PCB_Loop_40x40_4T / NFC_PCB_Loop_40x40_4T_W0.50_S0.30_InsideFeed: main-board
  antenna with both terminals inside the four-turn winding, an open-center
  courtyard, perimeter keepouts on all copper layers and a 6 mm B.Cu host-entry
  corridor. Accommodates the PN7160 and matching circuit inside the loop;
  ground must be confined to an intentional local region. Prototype RF values
  require measurement with the populated four-layer layout.
- NFC_PCB_Loop_40x40_4T_W0.50_S0.30: retained bare-coupon two-terminal
  PCB antenna replacing the three-pad placeholder. Four front copper turns,
  0.50 mm track / 0.30 mm gap, two plated return holes and a bottom underpass.
  Includes an all-copper-layer keepout and intentional net-tie declaration.
  No ground/shield pad, no discrete-part 3D model, excluded from purchased BOM
  and placement outputs. [Design and calculations](../docs/nfc-antenna.md).
- C_0805_HandSolder_NoPaste: KiCad's C_0805_2012Metric_Pad1.18x1.45mm_HandSolder
  geometry and standard model, with F.Paste removed for four optional RF trim pads.
  C53/C54 now use the standard footprint with paste and populated 33 pF parts.
- L_Coilcraft_0805HP: newly drawn from the manufacturer's 0805HP land pattern:
  1.02 × 1.98 mm pads with 1.12 mm gap, for L2/L3 = 0805HP-151XGRC (150 nH).
  No package model is claimed. RF electrical model is included in the calculations.
- L_Coilcraft_0805HQ_2012Metric and L_Coilcraft_LPS4018: unmodified KiCad land
  patterns copied locally with their missing optional 3D references removed.
  The 0805HQ footprint is retained as an unassigned legacy asset; L2/L3 now use
  the distinct 0805HP footprint above. L4 is LPS4018-103MRC.
  Manufacturer models are offered through Coilcraft's
  [mechanical model service](https://www.coilcraft.com/en-us/models/mechanical/),
  including a registration-based STEP export; these models are not installed.

PCF8574T, its SOIC-16W_7.5x10.3mm_P1.27mm footprint and package model use the
standard KiCad libraries. All assigned model paths resolve in the checked
installation. The verification report lists A1, L1–L4 and U6 as having no model.

The two user-supplied reference schematics remain under `parts documentation/`.
Their respective authors retain ownership; no broader redistribution license
is inferred. Downloaded SSD1309 and AP3012 datasheets retain their notices.

Olimex hardware source:
[ESP32-C3-DevKit-Lipo](https://github.com/OLIMEX/ESP32-C3-DevKit-Lipo),
Rev C, commit `5d93e79d46cf3b05782d9fe0f95a8a2e1ca6abbe`, © Olimex Ltd.
The adapted hardware schematic and Olimex-derived symbols retain
[CERN-OHL-S-2.0](../LICENSES/CERN-OHL-S-2.0.txt).

KiCad-derived library assets retain the
[KiCad CC-BY-SA-4.0 license with design exception](../LICENSES/KiCad-library-CC-BY-SA-4.0-exception.txt).
Original sources: [symbols](https://gitlab.com/kicad/libraries/kicad-symbols),
[footprints](https://gitlab.com/kicad/libraries/kicad-footprints),
[3D models](https://gitlab.com/kicad/libraries/kicad-packages3D).
Manufacturer datasheets retain their respective notices.

The added NXP AN13219 rev 1.6, Mohan inductance paper, Coilcraft RF model/land
drawing and Vishay resistor datasheet are archived under `parts documentation/`
for design traceability. [Source URLs and hashes](../docs/nfc/sources.json).

PN7160 datasheet rev. 4.2, NXP AN12988/AN14518 and both NDK CS06346 drawings
are also archived under `parts documentation/`. Samsung's numerical typical
DC-bias curves and JLCPCB's observed crystal sourcing stock are recorded in
`docs/components/`, with source URLs and retrieval dates. See the
[component refinements and calculations](../docs/component-refinements.md).

`Battery_Lead_SolderPads_2x2.2x2.5mm_P3.4mm` provides the two J6 battery wire
lands: pin 1 BAT+ on the right and pin 2 GND on the left. Both are 2.2 × 2.5 mm
front copper/mask pads with no holes or paste; J6 is excluded from BOM/CPL.

`MountingHole_2.2mm_M2_5.5mm_Keepout` is an original project mechanical
footprint for H1–H6. It uses the standard M2 2.2 mm clearance diameter and
reserves a 5.5 mm circle for hardware up to 5.0 mm diameter. The hole is
non-plated, without a copper annulus or stencil paste. Courtyards exist on
both faces; the four-layer rule excludes tracks, vias, fills and components.
Pads are allowed in the rule so its own NPTH can exist; the independent
mounting audit explicitly excludes every other pad from this area. The
footprint is board-only and excluded from the assembly BOM and placements.
